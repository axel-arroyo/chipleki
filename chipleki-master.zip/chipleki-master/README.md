Proyecto Análisis y Diseño de Software 2020-2 grupo Chipleki Chipleki ®

# Dependencias
## Backend
npm i express sequelize pg pg-hstore bcrypt jsonwebtoken dotenv cors

npm i -D nodemon sequelize-cli
## Frontend
npx create-react-app frontend --use-npm

npm i react-bootstrap bootstrap axios @reduxjs/toolkit react-redux react-router-dom moment
